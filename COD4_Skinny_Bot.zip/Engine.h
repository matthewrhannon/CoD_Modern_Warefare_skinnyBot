//skinnyM 10 april 08
#pragma once 

#include "skinnyBot.h"

struct TextRGBA
{
	unsigned long ulRed, ulGreen, ulBlue, ulAlpga;
};


extern char *Fonts[];		
#define TEXT_FONT char *

class CEngine
{
	public:
		static CEngine *Get()
		{
			if(!Instance)
				Instance = new CEngine;
			return Instance;
		};

		CEngine();
		~CEngine() 
		{
			if(Instance)
				delete Instance;
			Instance = NULL;
		};

		bool StartEngine();
		TEXT_FONT R_RegisterFont(char *strFont, int Unknown0);


		//ECX == *RGBA 32bit floats
		bool CEngine::CG_DrawStringExt(char *strText, int MaxLength, DWORD Font, float fX, float fY, float fScaleX, float fScaleY, TextRGBA Color, ...);

		
		/*
		005F58B0 ; int __cdecl CG_DrawTextPrimary(int, int, int, float, float, float, float, float, int)
ECX
000CFCF0   0CBE63E0  ASCII "(63-143, 2) 91"
000CFCF4   7FFFFFFF  Max signed int
000CFCF8   00F64CB4  B4A0A10E "fonts/smallDevFont" 
000CFCFC   440ED000  571.25000   
000CFD00   41B00000  22.000000
000CFD04   3FA00000  1.2500000
000CFD08   3FB00000  1.3750000
000CFD0C   00000000  Test nums
000CFD10   00000000  Test nums
000CFD14   00000010  What on earth?

00000000 0000803F 00000000 0000403F  
It is little indian only on the bytes, not the bits... therefore you read dump from right to left, and it shows proper 32bit float values.
RGBA is setup with 32 bit float for each...Further this is passed through ecx until the ParseColor function, where edx+0-3 become the 32bit uint which is actually passed into drawer..



		*/
		//ecx == 0 default color? what is second
	///	void __cdecl CG_DrawString(char *String, int *Font, float x, float y, float scaleX, float scaleY, RGBA *Color);
	//	int * __cdecl R_RegisterFont(char *FontName, int Unknown);

		//player instances, client instances
		//draw boxes, etc
		//everything an engine would do,
		//aimbot, esp, etc different calling into engine

	private:
		static CEngine *Instance;
		static int *PlzReturn;

		DWORD *pNormalFont;

	DWORD *pPlayerState_t;
	DWORD *pClientInfo_t; 

	//Also need R_RegisterFont shaders? and drawactiveframe
	DWORD *pCGS_t;		  //For local client number

//registerfont shaders for images?? put site image on screen menuu!
	DWORD *pR_StretchPIC; //whatever drawing function
	DWORD *pDrawString; //Draw string to screen
	DWORD *pCG_DRAW2D; //Need a place to render everything to the screen (add menu) (ESP)
	DWORD *pCG_FireWeapon; //One way to implement aimbot

};


