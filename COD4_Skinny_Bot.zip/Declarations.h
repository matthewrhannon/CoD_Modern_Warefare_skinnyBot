//skinnym april 10th 08
#pragma once 

#include "skinnyBot.h"

//void (__cdecl *fnDrawString)(char *String, void *Font, float x, float y, float scaleX, float scaleY);
//void *(__cdecl *fnRegisterFont)(char *FontName, int Unknown);
