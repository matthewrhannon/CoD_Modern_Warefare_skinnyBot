//skinnyBot March 29th 2008

#pragma once 

#include "skinnyBot.h"

#define ENV_OK 10
#define ENV_NOTOK 20

#define Junk 0x3f21
#define paste(a, b) a##b
#define pastesymbols(a, b) paste(a, b)

#define OBFUSCATE() \
	_asm { mov eax, __LINE__ * 0x635186f1		}; \
	_asm { cmp eax, __LINE__ * 0x9cb16d48		}; \
	_asm { je pastesymbols(Junk, __LINE__)		}; \
	_asm { mov eax, pastesymbols(Junk, __LINE__)}; \
	_asm { jmp eax								}; \
	_asm { pastesymbols(Junk, __LINE__)			}; \
	_asm { _emit (0xd8 + __LINE__ % 8)			}; \
	_asm { pastesymbols(Junk, __LINE__)			}; 

//typedef NTSTATUS (__stdcall *fnNtQueryInformationProcess)(HANDLE ProcessHandle, PROCESSINFOCLASS ProcessInformationClass, PVOID ProcessInformation, ULONG ProcessInformationLength, PULONG ReturnLength);

void _cdecl Crash();
bool _cdecl TestEnvironment();
bool _cdecl DetectTracing(DWORD oldTime);

extern void _cdecl InitalSingleStepCheck();
void _cdecl InitalSingleStepCheck();
