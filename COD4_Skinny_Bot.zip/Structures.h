//skinnyM april 10 2008
#pragma once 

#include "skinnyBot.h"

struct RGBA
{
	float Red, Green, Blue, Alpha;
};

struct VECTOR
{
	float x, y, z;
};

#define TYPE_SMOKEGRENADE	0
#define TYPE_HUMAN			1
#define TYPE_HUMANCORPSE	2
#define TYPE_WEAPON			3
#define TYPE_EXPLOSIVE		4
#define TYPE_VEHICLE		6
#define TYPE_CLAYMORELASER	8
#define TYPE_TURRET			11
#define TYPE_HELICOPTER		12

/*
Description of a couple i feel need to be emphasized

TYPE_SMOKEGRENADE = The left over sprite from an empty smoke grenade..not very useful
TYPE_WEAPON = Weapons that are on the ground, you can probably retrieve the name somehow, i haven't been bothered to reverse it
TYPE_EXPLOSIVE = Claymore/Grenade/etc
TYPE_TURRET = Those mounted machine guns
TYPE_CLAYMORELASER = Those red beams that trace against a player

*Edit*: Also, to check if the entity is a claymore, then just use dwFlags & 0x100000

.text:004026E0     mov     ebp, [eax-10h] // Move eax-10h into the extended base pointer..

.text:004026E3     imul    ebp, 1DCh // Multiply ebp with 0x1DC which is the structures size...

.text:004026E9     add     ebp, 84F058h // Add 0x84F058h to EBP which is the pointer to entity_t !!!

	memset( &cgs, 0, sizeof( cgs ) );
	memset( &cg, 0, sizeof( cg ) );
	memset( cg_entities, 0, sizeof(cg_entities) );
	memset( cg_weapons, 0, sizeof(cg_weapons) );
	memset( cg_items, 0, sizeof(cg_items) );

*///Generated using ReClass by DrUnKeN ChEeTaH



class cgs_t;
class cg_t;
class snapshot_t;
class entityState_t;
class trajectory_t;
class Vector;
class centity_t;
class clientInfo_t;
class playerState_t;
class CStats;

class cgs_t
{
public:
		char unknown0[8]; //0x0000
	DWORD screenX; //0x0008 screenX 
	DWORD screenY; //0x000C screenY 
	float screenXBias; //0x0010 screenXBias 
	DWORD serverCommandSequence; //0x0014 serverCommandSequence 
	DWORD processedSnapshotNum; //0x0018 processedSnapshotNum 
	DWORD boolLocalServer; //0x001C  
	char GameType[4]; //0x0020 Dom, sd, sab, war, koth=HQ, dm = free for all 
		char unknown36[28]; //0x0024
	char ServerName[256]; //0x0040  
	__int32 MaxClients; //0x0140  
	char MapName[64]; //0x0144  
	DWORD timeStartRound; //0x0184  
		char unknown392[10]; //0x0188
	char VoteString[28]; //0x0192  
	DWORD TimeLimit; //0x01AE  
	DWORD VoteTime; //0x01B2  
	DWORD YesVote; //0x01B6  
	DWORD NoVote; //0x01BA  
};//Size=0x01BE(446)


class playerState_t
{
public:
	__int32 commandTime; //0x0000 cmd->serverTime of last executed command 
	__int32 pm_type; //0x0004 4: spectating 7:ChooseClass 0:Playing 
	__int32 bobCycle; //0x0008 for view bobbing and footstep generation IDEA: possibly set to 0.1 
	__int32 pmFlag; //0x000C 0:Standing 1:Prone 2:Ducked 4:Climb 32:Fall 16384:Jump 16385:prone? 
	DWORD ID0F426990; //0x0010  
	__int32 old_pmType; //0x0014 Not really sure 
	__int32 pmTime; //0x0018  
	float orgin_X; //0x001C  
	float orgin_Z; //0x0020  
	float orgin_Y; //0x0024  
	float velocity_X; //0x0028  
	float velocity_Z; //0x002C  
	float velocity_Y; //0x0030  
		char unknown52[8]; //0x0034
	__int32 WeaponTime; //0x003C  
	__int32 WeaponDelay; //IDEA: hold to 0.1 for no delay to fire?; //0x0040  
	__int32 GrenadeTimeLeft; //0x0044  
		char unknown72[16]; //0x0048
	__int32 Gravity; //0x0058  
	float leanf; //0x005C  
	__int32 speed; //0x0060  
	__int32 delta_angles0; //0x0064  
	__int32 delta_angles1; //0x0068  
	__int32 delta_angles2; //0x006C  
	__int32 delta_angles3; //0x0070  
		char unknown116[12]; //0x0074
	__int32 IncreasesWhileJumping; //0x0080 no idea 
	float Jump_Y; //0x0084  
		char unknown136[4]; //0x0088
	__int32 movementDir; //0x008C  
		char unknown144[4]; //0x0090
	__int32 ID0F7CD498; //0x0094 It likes 512? 
		char unknown152[20]; //0x0098
	__int32 strafe_dir; //0x00AC  
	__int32 ShootingRate; //0x00B0 it goes up to 66 and then to 2 and stays 
	__int32 legsTimer; //0x00B4  
	__int32 events; //0x00B8  
	__int32 events1; //0x00BC  
	__int32 events2; //0x00C0  
	__int32 events3; //0x00C4  
	__int32 eventParms; //0x00C8  
	__int32 eventParms1; //0x00CC  
	__int32 eventParms2; //0x00D0  
	__int32 eventParms3; //0x00D4  
	__int32 torsoTimer; //0x00D8  
	DWORD clientNum; //0x00DC  
		char unknown224[8]; //0x00E0
	__int32 Weapon; //0x00E8  
	__int32 weaponState; //0x00EC  
		char unknown240[4]; //0x00F0
	float ID025BB560; //0x00F4  
		char unknown248[12]; //0x00F8
	__int32 Item; //0x0104 Not sure.. 
	float yaw; //0x0108 85 to -85 
	float pitch; //0x010C -PI to PI 
	float roll; //0x0110  
	__int32 viewHeight; //0x0114  
	float viewHeightF; //0x0118  
		char unknown284[28]; //0x011C
	__int32 damageCount; //0x0138  
	__int32 damagePitch; //0x013C  
	__int32 damage_Yaw; //0x0140  
	__int32 DamageAmount; //0x0144  
	__int32 Life; //0x0148  
		char unknown332[16]; //0x014C
	__int32 ID0F7979C0; //0x015C ///working on ammos!! 
	__int32 ID0F82BFF8; //0x0160  
	__int32 ID0F82C0A0; //0x0164 m9 : mp5 : mini_Uzi 
	__int32 ID0F82C148; //0x0168 m1014 : W1200 
	__int32 ID0F82C1F0; //0x016C m4 : M16A4 : G36C 
	__int32 ID0F793D80; //0x0170  
	__int32 ID0F82C340; //0x0174 golden desert eagle : Desert Eeagle 
	__int32 ID0F82C3E8; //0x0178  
	__int32 ID0F793718; //0x017C  
	__int32 ID0F793798; //0x0180 RPD 
	__int32 ID0F793840; //0x0184 barreta 50.cal 
	__int32 ID0F7938E8; //0x0188 AK-47 
	__int32 ID0F796F78; //0x018C usp 45.: M1911.45 
	__int32 ID0F793A38; //0x0190 Skorpion 
	__int32 ID0F793AE0; //0x0194 AK-74u 
	__int32 ID0F793B88; //0x0198  
	__int32 ID0F793C30; //0x019C m14 : m40a3 : G3 : M21 : R700 
	__int32 ID0F793CD8; //0x01A0 MP44 
	__int32 ID0F793990; //0x01A4 Dragunov 
	__int32 ID0F793E28; //0x01A8 m249 SAW 
	__int32 ID0F793ED0; //0x01AC m60e4 
	__int32 ID0F80E620; //0x01B0  
	__int32 ID0F7C3440; //0x01B4  
	__int32 ID0F7C34E8; //0x01B8  
	__int32 ID0F7C3590; //0x01BC  
	__int32 ID0F7C3638; //0x01C0  
	__int32 ID0F7C36E0; //0x01C4  
	__int32 ID0F7C3788; //0x01C8  
	__int32 ID0F7C3830; //0x01CC  
	__int32 ID0F7C38D8; //0x01D0  
	__int32 ID0F7C3980; //0x01D4  
	__int32 ID0F7C3A28; //0x01D8  
	__int32 ID027A4230; //0x01DC  
	__int32 ID0F831E98; //0x01E0  
	__int32 ID0F7EF558; //0x01E4  
	__int32 ID0F7EF600; //0x01E8  
	__int32 ID0F7EF6A8; //0x01EC  
	__int32 ID027A2FF8; //0x01F0  
	__int32 ID027A3078; //0x01F4  
	__int32 ID027A3120; //0x01F8  
	__int32 ID027A31C8; //0x01FC  
	__int32 ID027A3270; //0x0200  
	__int32 ID027A3318; //0x0204  
	__int32 ID027A33C0; //0x0208  
	__int32 ID027A3468; //0x020C  
	__int32 ID027A3510; //0x0210  
	__int32 ID027A35B8; //0x0214  
	__int32 ID027A3660; //0x0218  
	__int32 ID027A3708; //0x021C  
	__int32 ID027A37B0; //0x0220  
	__int32 ID027A3858; //0x0224  
	__int32 ID027A3900; //0x0228  
	__int32 ID027A39A8; //0x022C  
	__int32 ID027A3A50; //0x0230  
	__int32 ID027A3AF8; //0x0234  
	__int32 ID027A3BA0; //0x0238  
	__int32 ID027A3C48; //0x023C  
	__int32 ID027A3CF0; //0x0240  
	__int32 ID027A3D98; //0x0244  
	__int32 ID027A3E40; //0x0248  
	__int32 ID027A3EE8; //0x024C  
	__int32 ID027A3F90; //0x0250  
	__int32 ID027A4038; //0x0254  
	__int32 ID027A40E0; //0x0258  
	__int32 ID027A4188; //0x025C  
	__int32 ID0F7F4168; //0x0260  
	__int32 ID0F843F60; //0x0264  
	__int32 ID0279FA50; //0x0268  
	__int32 ID0F7F3F70; //0x026C  
	__int32 ID0F7F4018; //0x0270  
	__int32 ID0F7F40C0; //0x0274  
	__int32 ID0F7F42B8; //0x0278  
	__int32 ID0F7F4360; //0x027C  
	__int32 ID0F7F4408; //0x0280  
	__int32 ID0F7F44B0; //0x0284  
	__int32 ID0F7F4558; //0x0288  
	__int32 ID0F7F4600; //0x028C  
	__int32 ID0F7F46A8; //0x0290  
	__int32 ID0F7F4750; //0x0294  
	__int32 ID0F7F47F8; //0x0298  
	__int32 ID0F7F48A0; //0x029C  
	__int32 ID0F7F4948; //0x02A0  
	__int32 ID0F7F49F0; //0x02A4  
	__int32 ID0F7F4A98; //0x02A8  
	__int32 ID0F7F4B40; //0x02AC  
	__int32 ID0F7F4BE8; //0x02B0  
	__int32 ID0F7F4C90; //0x02B4  
	__int32 ID0F7F4D38; //0x02B8  
	__int32 ID0F7F4DE0; //0x02BC  
	__int32 ID0F7F4E88; //0x02C0  
	__int32 ID0F7F4F30; //0x02C4  
	__int32 ID0F7F4FD8; //0x02C8  
	__int32 ID0F7F5080; //0x02CC  
	__int32 ID0F7F5128; //0x02D0  
	__int32 ID0F7F51D0; //0x02D4  
	__int32 ID0F7F5278; //0x02D8  
	__int32 ID0F7F5320; //0x02DC  
	__int32 ID0F7F53C8; //0x02E0  
	__int32 ID0F7F5470; //0x02E4  
	__int32 ID0F7F5518; //0x02E8  
	__int32 ID0F7F55C0; //0x02EC  
	__int32 ID0F7F5668; //0x02F0  
	__int32 ID0F7F5710; //0x02F4  
	__int32 ID0F826D88; //0x02F8  
	__int32 ID0F826E30; //0x02FC  
	__int32 ID0F826ED8; //0x0300  
	__int32 ID0F826F80; //0x0304  
	__int32 ID0F827028; //0x0308  
	__int32 ID0F8270D0; //0x030C  
	__int32 ID0F827178; //0x0310  
	__int32 ID0F827220; //0x0314  
	__int32 ID0F8272C8; //0x0318  
	__int32 ID0F827370; //0x031C  
	__int32 ID0F827418; //0x0320  
		char unknown804[8]; //0x0324
};//Size=0x032C(812)



class cg_t
{
public:
		char unknown0[20]; //0x0000
	__int32 clientNum; //0x0014  
	__int32 latestSnapshotNum; //0x0018  
	__int32 latestSnapshotTime; //0x001C  
	snapshot_t* snap; //0x0020  
	snapshot_t* nextsnap; //0x0024  
		char unknown40[9804]; //0x0028
};//Size=0x2674(9844)

class snapshot_t
{
public:
	__int32 IncreasingValueMinutes; //0x0000  
	__int32 IncreatingValueMinutes; //0x0004  
	__int32 Ping; //0x0008  
	DWORD ID025BB890; //0x000C  
	playerState_t ID025C6340; //0x0010  
};//Size=0x033C(828)

class entityState_t
{
public:
	__int32 entity_number; //0x0000  
	__int32 eType; //0x0004 entityType_t 5:unactive 
	__int32 eFlags; //0x0008 2097154 = On choose screen 
	__int32 trType; //0x000C trType_t 
	__int32 trTime; //0x0010  
	__int32 trDuration; //0x0014  
	float trBase_X; //0x0018  
	float trBase_Z; //0x001C  
	float trBase_Y; //0x0020  
	float trDelta_X; //0x0024  
	float trDelta_Y; //0x0028  
	float trDelta_Z; //0x002C  
	__int32 trType1; //0x0030  
	__int32 trTime1; //0x0034  
	__int32 trDuration1; //0x0038  
	float trBase_X1; //0x003C  
	float trBase_Y1; //0x0040  
	float trBase_Z1; //0x0044  
	float trDelta_X1; //0x0048  
	float trDelta_Y1; //0x004C  
	float trDelta_Z1; //0x0050  
		char unknown84[32]; //0x0054
	__int32 otherEntityNum; //0x0074  
	__int32 otherEntityNum2; //0x0078  
		char unknown124[32]; //0x007C
	__int32 EventParam; //0x009C  
		char unknown160[48]; //0x00A0
	DWORD EntityType; //0x00D0  
		char unknown212[28]; //0x00D4
	__int32 animMovetype; //0x00F0  
};//Size=0x00F4(244)

class trajectory_t
{
public:
	__int32 trType; //0x0000 trType_t 
	__int32 trTime; //0x0004  
	__int32 trDuration; //0x0008  
	float trBase_X; //0x000C  
	float trBase_Z; //0x0010  
	float trBase_Y; //0x0014  
	float trDelta_X; //0x0018  
	float trDelta_Y; //0x001C  
	float trDelta_Z; //0x0020  
};//Size=0x0024(36)

class Vector
{
public:
	float X; //0x0000  
	float Y; //0x0004  
	float Z; //0x0008  
};//Size=0x000C(12)

class centity_t
{
public:
		char unknown0[4]; //0x0000
	entityState_t one; //0x0004  
		char unknown248[4]; //0x00F8
	entityState_t ID02731C48; //0x00FC  
		char unknown496[64]; //0x01F0
	__int32 Resolution_X; //0x0230  
	__int32 Resolution_Y; //0x0234  
		char unknown568[8]; //0x0238
	float raw_X; //0x0240  
	float raw_Z; //0x0244  
	float raw_Y; //0x0248  
	float raw_aX; //0x024C  
	float raw_aZ; //0x0250  
	float raw_aY; //0x0254  
	float lerp_X; //0x0258  
	float lerp_Z; //0x025C  
	float lerp_Y; //0x0260  
	float lerp_aX; //0x0264  
	float lerp_aZ; //0x0268  
	float lerp_aY; //0x026C  
	float lastLerpOrigin_X; //0x0270  
	float lastLerpOrigin_Z; //0x0274  
	float lastLerpOrigin_Y; //0x0278  
	__int32 ServerTime; //0x027C  
		char unknown640[24]; //0x0280
	float highlightOrigin_x; //0x0298  
	float highlightOrigin_Z; //0x029C  
	float highlightOrigin_Y; //0x02A0  
		char unknown676[2948]; //0x02A4
};//Size=0x0E28(3624)

class clientInfo_t
{
public:
	__int32 infoValid; //0x0000  
	__int32 ClientNum; //0x0004 Unaccurate 
		char unknown8[4]; //0x0008
	char Name[16]; //0x000C  
	__int32 team; //0x001C 1 2 3 = spec 
		char unknown32[12]; //0x0020
	__int32 Weapon; //0x002C  
		char unknown48[12]; //0x0030
	char ID027C59A0[64]; //0x003C  
	char ID02797A38[64]; //0x007C  
	char ID0274FAF8[64]; //0x00BC  
		char unknown252[320]; //0x00FC
	char TagModel[64]; //0x023C  
		char unknown636[284]; //0x027C
	float X; //0x0398  
	float Z; //0x039C  
	float Y; //0x03A0  
		char unknown932[8]; //0x03A4
	float angle_x; //0x03AC  
	float angle_z; //0x03B0  
	float angle_y; //0x03B4  
		char unknown952[36]; //0x03B8
	float Movement; //0x03DC  
		char unknown992[4]; //0x03E0
	float yaw; //0x03E4  
	float pitch; //0x03E8  
	float ID0266BE50; //0x03EC  
		char unknown1008[104]; //0x03F0
	__int32 currentWeaponSelect; //0x0458  
		char unknown1116[4]; //0x045C
	__int32 Climbing; //0x0460 1 = Trying to climb? 
		char unknown1124[12]; //0x0464
	DWORD SprintVelocity; //0x0470 2: not moving :1024 walking HUIGE: sprinting 
		char unknown1140[4]; //0x0474
	__int32 unknown2; //0x0478  
		char unknown1148[12]; //0x047C
	__int32 Shooting; //0x0488  
		char unknown1164[4]; //0x048C
	__int32 Zoomed; //0x0490  
		char unknown1172[4]; //0x0494
	__int32 Strafing; //0x0498 01 02 left right? 
		char unknown1180[52]; //0x049C
};//Size=0x04D0(1232)


class CStats
{
public:
	__int32 Cur_Xp; //0x0000  
	__int32 Cur_Score; //0x0004  
	__int32 Total_Kills; //0x0008  
	__int32 KillStreak; //0x000C  
	__int32 Total_Deaths; //0x0010  
		char unknown20[4]; //0x0014
	__int32 Assists; //0x0018  
	__int32 HeadShots; //0x001C  
		char unknown32[8]; //0x0020
	__int32 TotalTime0; //0x0028 Increment +4 seconds 
		char unknown44[8]; //0x002C
	__int32 TotalTime1; //0x0034 Increment +4 seconds +5 in second 
		char unknown56[8]; //0x0038
	__int32 Total_Games; //0x0040  
		char unknown68[16]; //0x0044
	__int32 Total_Hits; //0x0054  
	__int32 Total_Shots; //0x0058  
	__int32 Total_Shots1; //0x005C  
		char unknown96[100]; //0x0060
	__int32 Rank; //0x00C4  
		char unknown200[208]; //0x00C8
};//Size=0x0198(408)


