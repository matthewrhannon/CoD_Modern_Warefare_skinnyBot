//skinnym april 10 08
#pragma once 

#include "skinnyBot.h"

//Finding proper addresses relative of version changes (Hopefully...)
extern char *strCGS;
extern char *strCGSMask;

extern char *strClientInfo;
extern char *strClientInfoMask;

extern char *strSnapShot;
extern char *strSnapShotMask;






#define CG_DRAWSTRING 0x5CDB30
#define R_REGISTERFONT 0x005F0BE0