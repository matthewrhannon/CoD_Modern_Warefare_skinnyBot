//skinnym april 10th 2008

#include "Engine.h"

//Make sure static object is null
CEngine *CEngine::Instance = 0;
int *CEngine::PlzReturn = 0;

char *Fonts[] = {"fonts/normalfont", "fonts/boldfont" };

CEngine::CEngine()
{
	pNormalFont = NULL;
}

//TODO do findpatern for register font

TEXT_FONT CEngine::R_RegisterFont(char *strFont, int Unknown0)
{
	if(!strlen(strFont))
		CLog::Get()->WriteError("No font given");

	TEXT_FONT tFont = NULL;
	void *pRegisterFont = (void *)0x005F1EC0;
	__asm
	{
		pushad 

		push Unknown0
		push strFont

		call [pRegisterFont]
		mov tFont, eax

		add esp, 8

		popad
	}

	CLog::Get()->WriteEx("The font %s was created successfully! Value: %0.8X", strFont, (DWORD *)tFont);

	return tFont;
//	return tFont;
};


bool CEngine::StartEngine()
{
	//Put strings in table for better look
	DWORD *pdwSnapShot = (DWORD *)(dwFindPattern((BYTE*)strSnapShot, strSnapShotMask)+0x01);
	if(!pdwSnapShot)
		CLog::Get()->WriteError("Unable to find address for snapshot_t");
	else
		CLog::Get()->WriteEx("dwSnapShot: 0x%0.8X", *pdwSnapShot);

	DWORD *pdwCGS_t = (DWORD *)(dwFindPattern((BYTE *)strCGS, strCGSMask)+0x18);
	if(!pdwCGS_t)
		CLog::Get()->WriteError("Unable to find address for cgs_t");
	else
		CLog::Get()->WriteEx("dwCGS_t: 0x%0.8X", *pdwCGS_t);

	DWORD *pdwClientInfo_t = (DWORD *)(dwFindPattern((BYTE *)strClientInfo, strClientInfoMask)+0x32);
	if(!pdwClientInfo_t)
		CLog::Get()->WriteError("Unable to find address for clientinfo_t");
	else
		CLog::Get()->WriteEx("dwClientInfo_t: 0x%0.8X", *pdwClientInfo_t);
	Sleep(500);
	pNormalFont = (DWORD *)R_RegisterFont("fonts/normalfont", 1);
	//pNormalFont = (DWORD *)0x0CAF0708; //00F64CB4
	CLog::Get()->WriteEx("Font Normal Font: %0.8X", pNormalFont);

	return true;
};


//ECX == *RGBA 32bit floats
bool CEngine::CG_DrawStringExt(char *strText, int MaxLength, DWORD Font, float fX, float fY, float fScaleX, float fScaleY, TextRGBA Color, ...)
{





	return true;
};

		/*


fstp    [esp+20h+var_10]
fld     [esp+20h+arg_1C]
fstp    [esp+20h+var_14]
fld     [esp+20h+arg_18]
fstp    [esp+20h+var_18]
fld     [esp+20h+arg_14]
fstp    [esp+20h+var_1C]
fld     [esp+20h+arg_10]
fstp    [esp+20h+var_20]
push    ecx             ; int
mov     ecx, [esp+24h+arg_20]
push    edx             ; int
push    eax             ; int
call    CG_DrawTextPrimary
add     esp, 24h

005F58B0 ; int __cdecl CG_DrawTextPrimary(int, int, int, float, float, float, float, float, int)

000CFCF0   0CBE63E0  ASCII "(63-143, 2) 91"
000CFCF4   7FFFFFFF  Max signed int
000CFCF8   00F64CB4  B4A0A10E "fonts/smallDevFont" 
000CFCFC   440ED000  571.25000   
000CFD00   41B00000  22.000000
000CFD04   3FA00000  1.2500000
000CFD08   3FB00000  1.3750000
000CFD0C   00000000  Test nums
000CFD10   00000000  Test nums
000CFD14   00000010  What on earth?

ECX
00000000 0000803F 00000000 0000403F  
It is little indian only on the bytes, not the bits... therefore you read dump from right to left, and it shows proper 32bit float values.
RGBA is setup with 32 bit float for each...Further this is passed through ecx until the ParseColor function, where edx+0-3 become the 32bit uint which is actually passed into drawer..



		*/

/*(
drawstring
iw3mp Base 400000 Size d536000 \x8B\x44\x24\x04\x80\x38\x00\x0F\x84\x00\x00\x00\x00\x56\x8D\x70\x01\x8A\x10\x83\xC0\x01\x84\xD2\x75\xF7\x8B\x15\x00\x00\x00\x00\x2B\xC6\x8B\x72\x08\x53 xxxxxxxxx????xxxxxxxxxxxxxxx????xxxxxx

registershader
iw3mp Base 400000 Size d536000 \x8B\x44\x24\x04\x89\x44\x24\x08\xC7\x44\x24\x00\x00\x00\x00\x00\xE9\x00\x00\x00\x00 xxxxxxxxxxx?????x????


	DWORD *pClientInfo_t;  ***
	DWORD *pCGS_t;	

	DWORD *pPlayerState_t;
	DWORD *pClientInfo_t; 

	//Also need R_RegisterFont shaders? and drawactiveframe
	DWORD *pCGS_t;		  //For local client number

//registerfont shaders for images?? put site image on screen menuu!
	DWORD *pR_StretchPIC; //whatever drawing function
	DWORD *pDrawString; //Draw string to screen
	DWORD *pCG_DRAW2D; //Need a place to render everything to the screen (add menu) (ESP)
	DWORD *pCG_FireWeapon; //One way to implement aimbot



		static		void		ASM_DrawString( char * pFont, float fPosX, float fPosY, float * pColor, char * pString, ... );
		static		void		*ASM_GetFont( const char * Name );
		static		void		CG_DrawStretchPic(float x, float y, float w, float h, float f1, float f2, float f3, float f4, float * color, int iMaterial );





	static int *Font = NULL;
	if(!Font)
		Font = R_RegisterFont("fonts/consoleFont", 2);
	
	if(!Font)
		CLog::Get()->WriteError("Font invalid");

	RGBA Color = {1.0f, 0.0f, 0.0f, 1.0f};


	CG_DrawString("FUCK Y444444EAH", Font, 1, 1, 2, 2, &Color);
	
*/

/*
.text:005D02EB loc_5D02EB:             ; Unknown
.text:005D02EB push    1
.text:005D02ED push    offset aFontsConsolefo ; "fonts/consoleFont"
.text:005D02F2 call    eax ; R_RegisterFont
.text:005D02F4 fldz
.text:005D02F6 add     esp, 8
.text:005D02F9 push    0               ; unknown1
.text:005D02FB sub     esp, 14h
.text:005D02FE fst     [esp+20h+var_10] ; 0
.text:005D0302 mov     ecx, offset unk_6B78B8 ; 0
.text:005D0307 fld     ds:flt_6FF93C   ; 2.0
.text:005D030D fstp    [esp+20h+var_14]
.text:005D0311 fld     ds:flt_70A200   ; 1.5
.text:005D0317 fstp    [esp+20h+var_18]
.text:005D031B fld     ds:flt_70AB30   ; 3.4e2
.text:005D0321 fstp    [esp+20h+var_1C]
.text:005D0325 fstp    [esp+20h+var_20]
.text:005D0328 push    eax             ; Font
.text:005D0329 push    7FFFFFFFh       ; signedvalue
.text:005D032E push    offset aGlow    ; "GLOW"
.text:005D0333 call    CG_DrawString
.text:005D0338 add     esp, 24


*/

/* //PRINT TEXT version
void __cdecl CEngine::CG_DrawString(char *String, int *Font, float x, float y, float scaleX, float scaleY, RGBA *Color)
{
	//(char *String, void *unknown0, void *Font, float x, float y, float scaleX, float scaleY, int unknown, int unknown1);
	BYTE *func = (BYTE *)0x542D40;
	float value = 0.3f;
	__asm
	{
		push 3
		push Color
		push value
		push y
		push x
		push Font
		push 7FFFFFFFh
		push String
		push 0E341A0h

		mov ecx, Color

		xor eax, eax
		call func
		add esp, 24h
	}
}
*/
//black screeeeen




