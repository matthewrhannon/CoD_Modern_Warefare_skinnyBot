//skinnyBot March 29th 2008

#pragma once

#define WIN32_LEAN_AND_MEAN

#define _CRT_SECURE_NO_DEPRECATE //Annoying

#pragma warning(disable:4996) //Depreciation annoyance
#pragma warning(disable:4254) //Merging attributes
#pragma warning(disable:4312) //DWORD to DWORD * of greater size

//#pragma comment(linker,"/MERGE:.text=.sys /MERGE:.data=.sys /MERGE:.rdata=.sys /SECTION:.sys,EWR")
/*
#pragma comment(linker, "/MERGE:.text=.data")
#pragma comment(linker, "/MERGE:.rdata=.data")
#pragma comment(linker, "/SECTION:.ium,RWE")
#pragma comment(linker, "/MERGE:.data=.ium")
*/
#include <windows.h>
#include <stdio.h>
#include <stdlib.h> //itoa etc
#include <tlhelp32.h>
#include <assert.h>
#include <psapi.h>
#include <Winternl.h>

#include "Declarations.h"
#include "Offsets.h"
#include "Structures.h"
#include "Utilities.h"
#include "Engine.h"
#include "AntiDebug.h"
#include "Logging.h"

#define inline __forceinline

#pragma comment(lib, "psapi.lib")

#define PROGRAM_NAME "skinnyBot"
#define PROGRAM_VERSION "0.1 Alpha"

#define TARGET_NAME "iw3mp"
#define TARGET_WINDOW_NAME "Call of Duty 4"

#define uint unsigned int
#define uchar unsigned char

extern char gBuffer[512];
extern void WindowsError();

#define SafeDelete(Object) {if(Object) delete Object; Object = 0}

#define QuickMsg(Text) MessageBox(NULL, Text, "Quick Message", MB_OK)

void MsgBox(char *Text, ...);
void MsgBox(char *Text, ...)
{
	va_list List;
	char Temp[256];

	va_start(List, Text);
		vsprintf(Temp, Text, List);
	va_end(List);

	MessageBox(GetDesktopWindow(), Temp, "Information", MB_OK | MB_APPLMODAL);
}

void MsgBoxError(char *Text, ...);
void MsgBoxError(char *Text, ...)
{
	va_list List;
	char Temp[256], Temp1[256];

	va_start(List, Text);
		vsprintf(Temp, Text, List);
	va_end(List);

	sprintf(Temp1, "Error: %s", Temp);

	MessageBox(GetDesktopWindow(), Temp1, "Application Error", MB_OK | MB_ICONSTOP | MB_APPLMODAL);
}

int WindowsErrorMsg();
int WindowsErrorMsg()
{
    FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), 0, (LPTSTR)gBuffer,512, NULL);
    MessageBox(NULL, gBuffer, "Diablo 2 Save Game Editor", MB_OK | MB_ICONINFORMATION);
  
	return false;
}


