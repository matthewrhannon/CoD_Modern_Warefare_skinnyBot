//skinnyBot March 28th 2008

#include "Utilities.h"

char gBuffer[512];

void WindowsError()
{
	static char Error[256];
	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(),0, (LPTSTR)Error, 256, NULL);
	MsgBoxError(Error);
}

//Note: return is invalid if .dwSize = 0
PROCESSENTRY32 FindProcess(char *strName)
{
	PROCESSENTRY32 tPe, tPe1;
	tPe.dwSize = sizeof(PROCESSENTRY32);
	tPe1.dwSize = 0;
	
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if(hSnapshot == INVALID_HANDLE_VALUE)
	{
		MsgBoxError("Couldnt create process snapshot!");
		return tPe1;
	}

	if(!Process32First(hSnapshot, &tPe))
	{
		MsgBoxError("Error obtaining first process structure!");
		CloseHandle(hSnapshot);

		return tPe1;
	}

	if(!strstr(tPe.szExeFile, strName))
	{
		do
		{
			if(strstr(tPe.szExeFile, strName))
			{
				CloseHandle(hSnapshot);
				return tPe;
			}

		} while(Process32Next(hSnapshot, &tPe));
	}
	else
	{
		CloseHandle(hSnapshot);
		return tPe;
	}

	//Reached here, not found
	CloseHandle(hSnapshot);
	return tPe1;
}

HANDLE _cdecl GetProcessHandle()
{
	HANDLE hReturn = NULL;
	HANDLE hProcess = NULL;
	DWORD dwProcesses[1024], dwNeeded, dwProcessNum;

	if (!EnumProcesses(dwProcesses, sizeof(dwProcesses), &dwNeeded))
		return NULL;
	
	//Number of processes
	dwProcessNum = dwNeeded / sizeof(DWORD);

	for(uint x = 0; x < dwProcessNum; x++)
	{
		if(dwProcesses[x] != 0)
		{
			hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, dwProcesses[x]);

			if(!hProcess)
				continue;

			static HMODULE hMod;
			static char strProcessName[256];

			if(EnumProcessModules(hProcess, &hMod, sizeof(hMod), &dwNeeded))
				GetModuleBaseName(hProcess, hMod, strProcessName, 256);

			if(strstr(strProcessName, TARGET_NAME) != NULL)
			{
				hReturn = hProcess;
				CloseHandle(hProcess); 
				
				assert(hReturn); //Possible error, invalid handle returned
				return hReturn;
			}
			else
				CloseHandle(hProcess);
		}
	}

	return NULL;
}

DWORD _cdecl GetProcessPID()
{
	HANDLE hProcess = NULL;
	DWORD dwProcesses[1024], dwNeeded, dwProcessNum;

	if (!EnumProcesses(dwProcesses, sizeof(dwProcesses), &dwNeeded))
		return NULL;
	
	//Number of processes
	dwProcessNum = dwNeeded / sizeof(DWORD);

	for(uint x = 0; x < dwProcessNum; x++)
	{
		if(dwProcesses[x] != 0)
		{
			hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, dwProcesses[x]);

			if(!hProcess)
				continue;

			static HMODULE hMod;
			static char strProcessName[256];

			if(EnumProcessModules(hProcess, &hMod, sizeof(hMod), &dwNeeded))
				GetModuleBaseName(hProcess, hMod, strProcessName, 256);

			if(strstr(strProcessName, TARGET_NAME) != NULL)
			{
				CloseHandle(hProcess); 
				return dwProcesses[x];
			}
			else
				CloseHandle(hProcess);
		}
	}

	return NULL;
}

// Credits: Dominik, Patrick
unsigned long dwStartAddress = 0x00401000, dwLen = 0x00861FFF;

bool bDataCompare(const unsigned char* pData, const unsigned char* bMask, const char* szMask)
{
    for(;*szMask;++szMask,++pData,++bMask)
        if(*szMask=='x' && *pData!=*bMask )
            return false;
    return (*szMask) == 0;
}

unsigned long dwFindPattern( unsigned char *bMask,char * szMask)
{
	unsigned long dw_Address = dwStartAddress;
	unsigned long dw_Len = dwLen;

    for(unsigned long i=0; i < dw_Len; i++)
		if( bDataCompare( (unsigned char*)( dw_Address+i ),bMask,szMask) )
            return (unsigned long)(dw_Address+i);
    return 0;
}
