//skinnyBot March 29th 2008

#pragma once

#include "skinnyBot.h"

HANDLE _cdecl GetProcessHandle();
DWORD _cdecl GetProcessPID();
PROCESSENTRY32 FindProcess(char *strName);

// Credits: Dominik, Patrick
extern unsigned long dwStartAddress, dwLen;

bool bDataCompare( const unsigned char* pData, const unsigned char* bMask, const char* szMask );
unsigned long dwFindPattern( unsigned char *bMask,char * szMask);

