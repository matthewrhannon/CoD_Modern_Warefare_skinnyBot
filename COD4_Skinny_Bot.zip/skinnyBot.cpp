//skinnyBot March 29th 2008

#include "skinnyBot.h"

HANDLE hLoadThread = NULL;

void *DetourFunc(BYTE *src, const BYTE *dst, const int len)
{
	BYTE *jmp = (BYTE*)malloc(len+5);
	DWORD dwBack;

	VirtualProtect(src, len, PAGE_READWRITE, &dwBack);

	memcpy(jmp, src, len);	
	jmp += len;
	
	jmp[0] = 0xE9;
	*(DWORD*)(jmp+1) = (DWORD)(src+len - jmp) - 5;

	src[0] = 0xE9;
	*(DWORD*)(src+1) = (DWORD)(dst - src) - 5;

	for( int i=5; i < len; i++ )
		src[i] = 0x90;

	VirtualProtect(src, len, dwBack, &dwBack);

	return (jmp-len);
}

void RetourFunc(BYTE *src, BYTE *restore, const int len)
{
	DWORD dwBack;
		
	VirtualProtect(src, len, PAGE_READWRITE, &dwBack);
	memcpy(src, restore, len);

	restore[0] = 0xE9;
	*(DWORD*)(restore+1) = (DWORD)(src - restore) - 5;

	VirtualProtect(src, len, dwBack, &dwBack);
}


typedef int (__cdecl *fnDrawActiveFrame)(int, int, int, int, int);
fnDrawActiveFrame oldDrawActiveFrame = NULL;

int __cdecl hkDrawActiveFrame(DWORD unknown1, DWORD unknown2, DWORD unknown3, DWORD unknown4, DWORD unknown5)
{

	int ret = oldDrawActiveFrame(unknown1, unknown2, unknown3, unknown4, unknown5);
	return ret;
}

typedef void (*fnDraw2D)();
fnDraw2D oldDraw2D = NULL;


TextRGBA ColorWhite = {1.0, 1.0, 1.0, 1.0};
/*
__declspec( naked ) void CG_DrawString(char *String, int *Font, float x, float y, float scaleX, float scaleY, RGBA *Color)
{
	//(char *String, void *unknown0, void *Font, float x, float y, float scaleX, float scaleY, int unknown, int unknown1);
	__asm
	{	
		push ecx
		push eax

		push 0
		push 6
		push 2
		push 2
		push 1
		push 2

		push Return
		push 7FFFFFFFh //Figure out
		push offset FUCK


		mov ecx, offset color
		mov eax, CG_DRAWSTRING
		call eax
		add esp, 24h

		pop eax
		pop ecx
		retn
	}
}



void __declspec(naked) h_RE_EndFrame( )
{
	__asm
	{
		pushad
	}


	__asm
	{
		popad
		jmp [o_RE_EndFrame]
	}
}





*/

	void *Dest = (void *)0x005F6B00;
////change not to draw2d, do r_renderscene!!!!!! try that moron and make it look nice
//__cdecl
void hkDraw2D(float fX, float fY, fScaleX, fScaleY, FONT_TEXT Font,  char *strText)
{	
	//static bool once = false;
//CLog::Get()->Write("In hkdraw2d2222");
//	CEngine::Get()->CG_DrawStringExt("!Go dfasdfssdfsfdfsdsdfMatt!", 10, (DWORD)0xB4A0A10E, 0.0f, 00.0f, 5.0f, 5.0f, (float *)color);
	__asm
	{
		pushad
	}
//CLog::Get()->Write("In hkdraw2d22122");

	
	//Now Call the game's draw string function


	__asm
	{
		lea ecx, dword ptr [Color]

		push 0
		push 0
		push fScaleY  //Advice:: Start from fresh, and/or debug this sequence directly to see whats up, or different than a base
		push fScaleX
		push fY
		push fX
		push pNormalFont //TODO Replace with param
		push 0x7FFFFFFF
		//push dword ptr [cText] //Simplicity
		push strText

		call [Dest]
		add esp, 24h	
	}



	//CEngine::Get()->CG_DrawStringExt("!Go Mfdssdsdffdfdsfafdsfsdasdfsdfsdfsddsfdaatt!", 10, (DWORD)0xB4A0A10E, 300.0f, 300.0f, 2.0f, 1.0f, ColorWhite);
	//oldDraw2D;

	__asm
	{
		popad
		jmp [oldDraw2D]
	}
}


DWORD WINAPI InitalizeThread(LPVOID Parameter);
/*
__declspec( naked ) void R_RegisterFont(char *FontName, int Unknown)
{
	__asm
	{
		push eax
		push Unknown
		push FontName
		
		mov eax, R_REGISTERFONT
		call eax

		mov Return, eax
		add esp, 8			
		pop eax
		
	}	

	CLog::Get()->WriteEx("Handle to font: %X", Return);
}
*/



































DWORD WINAPI InitalizeThread(LPVOID Parameter)
{
		Sleep(500);
		CLog::Get()->WriteEx("Entering Inital Thread");
		CEngine::Get()->StartEngine();
	
/*
	R_RegisterFont("fonts/consoleFont", 1);

	if(!dwSmallFont)
		CLog::Get()->WriteError("Unable to create smallDevFont! Return: %0.8X", dwSmallFont);
	else
		CLog::Get()->WriteError("smallDevFont Created at %0.8X", dwSmallFont);
*/
		//0042F650 CG_Draw2D
	//if(!Return)
		//	R_RegisterFont("fonts/consoleFont", 1);

		//BYTE *func = (BYTE *)0x452830;
		//oldDrawActiveFrame = (fnDrawActiveFrame)DetourFunc(func, (BYTE *)hkDrawActiveFrame, 5);
		
		BYTE *func = (BYTE *)0x005F98E0;//0x005FAF00;//0x0042F590;
		oldDraw2D = (fnDraw2D)DetourFunc(func, (BYTE *)hkDraw2D, 6);


//Start:
		Sleep(300);

	//if(GetAsyncKeyState(VK_HOME) & 1)
//	{
		//CEngine::Get()->CG_DrawStringExt("!Go Matt!", (int)strlen("!Go Matt!"), (DWORD *)0x00F64CB4, 200.0f, 100.0f, 2.0f, 2.0f, &Color);
	//	CLog::Get()->Write("EXECUTING");
	//}

	//if(!(GetAsyncKeyState(VK_END) & 1))
	//{
	//	goto Start;
	//}



	return 1;
}



bool __stdcall DllMain(HINSTANCE hInst, DWORD dwReason, LPVOID pvReserved)
{
	if(dwReason == DLL_PROCESS_ATTACH)
	{
		//DisableThreadLibraryCalls(hModule);
		CLog::Get()->Load();
			
		//Make into a thread! MORON
		hLoadThread = CreateThread(NULL, 0, InitalizeThread, NULL, NULL, NULL);
		if(!hLoadThread)
		{
			MsgBoxError("Error creating inital thread");
			return false;
		}





		/*
		//InitalSingleStepCheck();

		//do random code generation here
		//complete time stamp counter
		//begin cod4 hack with decent base
		//possibly change entry? research more!
		if(GetProcessHandle() == NULL)
		{
			MsgBoxError("CoD4 Process NOT Found");
			return false;
		}

		if(TestEnvironment()) //Debug?
		{
			MsgBox("Cool");

		}
		else
		{
			//Program should have crashed...
			MsgBoxError("Debugger detection");
		}
		*/
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		/*
		BYTE *func = (BYTE *)0x452830;
		RetourFunc(func, (BYTE *)oldDrawActiveFrame, 5);
*/
		BYTE *func = (BYTE *)0x00474FF0;
		RetourFunc(func, (BYTE *)oldDraw2D, 6);
	
		CLog::Get()->Write("Unloading");
		CLog::Get()->UnLoad();
		
	}
	
	return true;
}




/*
WinMain.cpp
// Main.cpp from D2E
#include "JamellaD2E.h"
#include <time.h>
#include <shlwapi.h>
HINSTANCE hInstance;
inline void DoCRC();
DWORD GetDllVersion(LPCTSTR DllName)
{
    HINSTANCE hInst;
    DWORD dwVersion = 0;
    hInst = LoadLibrary(DllName);
    
    if(hInst)
    {
        DLLGETVERSIONPROC pDllGetVersion;
        pDllGetVersion = (DLLGETVERSIONPROC) GetProcAddress(hInst,"DllGetVersion");
        if(pDllGetVersion)
        {
            DLLVERSIONINFO dvi;
            HRESULT hr;
            ZeroMemory(&dvi, sizeof(dvi));
            dvi.cbSize = sizeof(dvi);
            hr = (*pDllGetVersion)(&dvi);
            if (hr == NOERROR)
            {
                dwVersion = MAKEWORD(dvi.dwMinorVersion,dvi.dwMajorVersion);
            }
        }
        FreeLibrary(hInst);
    }
    return dwVersion;
}
int PASCAL WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpszCmdLine,
                   int nCmdShow)
{
    ::hInstance = hInstance;
    srand((unsigned)time(NULL));
    if(GetDllVersion(TEXT("comctl32.dll")) < _WIN32_IE)
    {
        ErrorBox("Your system uses a Common Control Library prior to 5.80.\nThe editor requires one >= 5.80.\nDownload i
t from my web pages http://jamella.dyns.cx or from Microsoft.");
        return -1;
    }
    INITCOMMONCONTROLSEX cci;
    cci.dwSize = sizeof cci;
    cci.dwICC = ICC_PROGRESS_CLASS | ICC_TAB_CLASSES | ICC_TREEVIEW_CLASSES;
    if (!InitCommonControlsEx(&cci))
    {
        ErrorBox("The editor could not initialize the common control library.\nThis is major operating system failure. Y
ou better watch out.");
        return -1;
    }
    HINSTANCE hRichEdit = LoadLibrary("RICHED32.DLL");
    if (!hRichEdit)
    {
        ErrorBox("The editor could not load the RichEdit library.\nDownload it from my web pages http://jamella.dyns.cx 
or from Microsoft.");
        return -1;
    }
    // Parse Command Line Options
    ParseCommandLine();
WinMain.cpp
//  DoCRC();
    LoadEditorRegistryValues();
    int x = MainDialog(lpszCmdLine);
    FreeLibrary(hRichEdit);
    return x;
}
int ErrorMessage()
{
    char str[260];
    FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM,
        NULL,
        GetLastError(),0,
        (LPTSTR) str,260,
        NULL);
    MessageBox(NULL,str,"Diablo 2 Save Game Editor",
        MB_OK | MB_ICONINFORMATION);
    return false;
}
inline void DoCRC()
{
    // Open File
    HANDLE hFile = CreateFile(ProgramFilePath(),
        GENERIC_READ,FILE_SHARE_READ,NULL,
        OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    
    if (hFile == INVALID_HANDLE_VALUE)
    {
        MessageBox(NULL,"Could not open program file for CRC checking!",PROGRAMNAME,
            MB_OK | MB_ICONSTOP | MB_APPLMODAL);
        exit(0);
    }
    const int CRCsize = 1024*3*4;
    BYTE CRCbuffer[CRCsize];
    DWORD *CRCbufferd = (DWORD*)CRCbuffer;
    DWORD CRCread;
    DWORD   fsizeread = 0;
    DWORD   CRC = 0;
    while(ReadFile(hFile,CRCbuffer,CRCsize,&CRCread,NULL))
    {
        if (CRCread == 0) break;
        fsizeread += CRCread;
        for(int z=0;z<CRCsize/3/4;z+=3)
        {
            CRC += CRCbufferd[z+0] * 1;
            CRC += CRCbufferd[z+1] * 3;
            CRC += CRCbufferd[z+2] * 7;
        }
    }
    if (CRC != 0x00000000)
    {
        MessageBox(NULL,"CRC check of program file failed! This executable was tampered with.\nGet a new one from http:/
/jamella.dyns.cx!",PROGRAMNAME,
            MB_OK | MB_ICONSTOP | MB_APPLMODAL);
        exit(0);
    }
    CloseHandle(hFile);
}




*/