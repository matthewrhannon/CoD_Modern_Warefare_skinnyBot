
//********************************************//
//				Log System
//********************************************//

#pragma once 

#include "skinnyBot.h"

class CLog
{
	public:
		static CLog *Get()
		{
			if(!Instance)
				Instance = new CLog;
			return Instance;
		}

		CLog();
		~CLog();

		void Load();
		void UnLoad();
		
		void Write(char *Text);
		void WriteEx(char *Text, ...);
		void WriteError(char *Text1, ...);
		void LineDown();

	private:
		static CLog *Instance;
		FILE *LogFile;
		//TODO FIX THIS CHAOS
		bool Extensions;
		char TempString[64];
		char TempString1[64];
		char ExtensionString[512];
		char LogPath[32];
};
