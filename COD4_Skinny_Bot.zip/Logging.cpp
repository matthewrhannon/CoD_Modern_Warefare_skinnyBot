
#include "Logging.h"

CLog *CLog::Instance = 0;

CLog::CLog()
{
	LogFile = NULL;
	Extensions = false;


	GetCurrentDirectory(512, gBuffer);
	strcpy(LogPath, PROGRAM_NAME);
	strcat(LogPath, ".txt");
}

CLog::~CLog()
{
	if(Instance)
		delete Instance;
	Instance = 0;
}

void CLog::Load()
{
	LogFile = fopen(LogPath, "w");

	if(!LogFile)
		return;

	//Come up with way to have local path with injector... should be easy
	

	fputs("******************************", LogFile);

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::UnLoad()
{
	if(!LogFile)
		LogFile = fopen(LogPath, "a+");

	fputs("\n******************************", LogFile);
	
	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::Write(char *Text)
{
	static char Text1[256];

	if(!strlen(Text))
		return;

	if(!LogFile)
		LogFile = fopen(LogPath, "a+");

	sprintf(Text1, "\n%s", Text);

	fputs(Text1, LogFile);

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::WriteEx(char *Text, ...)
{
	static char Text1[256];
	
	if(!strlen(Text))
		return;
	
	va_list List;
	char Temp[256];

	va_start(List, Text);
		vsprintf(Temp, Text, List);
	va_end(List);

	sprintf(Text1, "\n%s", Temp);
	
	if(!LogFile)
		LogFile = fopen(LogPath, "a+");

	fputs(Text1, LogFile);

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::WriteError(char *Text1, ...)
{
	va_list TempList1;

	if(!strlen(Text1))
		return;

	va_start(TempList1, Text1);
		vsprintf(TempString1, Text1, TempList1);
	va_end(TempList1);
	
	sprintf(TempString1, "\n   %s", TempString1);
	
	if(!LogFile)
		LogFile = fopen(LogPath, "a+");

	fputs(TempString1, LogFile);
		
	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::LineDown()
{
	if(!LogFile)
		LogFile = fopen(LogPath, "a+");

	fputc('\n', LogFile);

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}
